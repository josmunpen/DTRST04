README.txt
----------

There are not any specific materials for 
this project work session.